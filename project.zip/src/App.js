import React, { useState } from 'react';
import LayoutHeader from './components/LayoutHeader';
import HomePage from './components/HomePage';
import ServicesPage from './components/ServicesPage';
import AboutPage from './components/AboutPage';
import TestimonialsSection from './components/TestimonialsSection'; // Importar el nuevo componente

const App = () => {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <>
            <HomePage />
            <TestimonialsSection /> {/* Añadir la sección de testimonios aquí */}
          </>
        );
      case 'services':
        return <ServicesPage />;
      case 'about':
        return <AboutPage />;
      case 'contact':
        return (
          <div className="min-h-[calc(100vh-64px)] bg-gray-100 p-8 flex flex-col items-center justify-center">
            <h2 className="text-4xl font-bold text-center text-red-700 mb-8">Contacto</h2>
            <div className="max-w-md w-full bg-white p-8 rounded-lg shadow-lg">
              <p className="text-gray-700 mb-4 text-center">
                ¿Tienes preguntas? ¡Contáctanos!
              </p>
              <form className="space-y-4">
                <input
                  type="text"
                  placeholder="Tu Nombre"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-700 transition"
                />
                <input
                  type="email"
                  placeholder="Tu Correo Electrónico"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-700 transition"
                />
                <textarea
                  placeholder="Tu Mensaje"
                  rows="4"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-700 transition resize-none"
                ></textarea>
                <button
                  type="submit"
                  className="w-full bg-red-700 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors font-semibold"
                >
                  Enviar Mensaje
                </button>
              </form>
            </div>
          </div>
        );
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <LayoutHeader setCurrentPage={setCurrentPage} />
      <main>
        {renderPage()}
      </main>
    </div>
  );
};

export default App;

// DONE
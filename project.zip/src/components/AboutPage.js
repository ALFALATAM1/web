import React from 'react';

const AboutPage = () => {
  return (
    <div className="min-h-[calc(100vh-64px)] bg-gray-100 p-8 flex flex-col items-center justify-center">
      <h2 className="text-4xl font-bold text-center text-red-700 mb-8">Sobre Nosotros</h2>
      <div className="max-w-4xl bg-white p-8 rounded-lg shadow-lg text-gray-700 leading-relaxed">
        <h3 className="text-2xl font-semibold text-gray-800 mb-4">Nuestra Historia</h3>
        <div className="flex flex-col md:flex-row items-center mb-6">
          <img
            src="https://via.placeholder.com/300x200?text=Fundacion"
            alt="Imagen de Fundación"
            className="w-full md:w-1/2 rounded-lg shadow-md mb-4 md:mb-0 md:mr-6"
          />
          <p className="mb-4 md:mb-0">
            ALFA LATAM nació de la visión de un grupo de expertos financieros con el objetivo de democratizar el acceso a los mercados en América Latina. Fundada en [Año de Fundación], nuestra empresa ha crecido de manera constante, adaptándose a las dinámicas del mercado y a las necesidades de nuestros clientes.
          </p>
        </div>
        <div className="flex flex-col md:flex-row items-center mb-6">
          <p className="mb-4 md:mb-0 md:mr-6">
            Desde nuestros inicios, nos hemos comprometido con la innovación, la transparencia y la educación. Hemos desarrollado plataformas intuitivas y programas de capacitación robustos para asegurar que tanto inversores novatos como experimentados puedan operar con confianza y éxito.
          </p>
          <img
            src="https://via.placeholder.com/300x200?text=Innovacion"
            alt="Imagen de Innovación"
            className="w-full md:w-1/2 rounded-lg shadow-md"
          />
        </div>
        <div className="flex flex-col md:flex-row items-center mb-6">
          <img
            src="https://via.placeholder.com/300x200?text=Crecimiento"
            alt="Imagen de Crecimiento"
            className="w-full md:w-1/2 rounded-lg shadow-md mb-4 md:mb-0 md:mr-6"
          />
          <p className="mb-4 md:mb-0">
            Hoy, ALFA LATAM es reconocida como un líder en el sector, gracias a la confianza de miles de clientes que han logrado sus metas financieras con nuestro apoyo. Seguimos expandiendo nuestras operaciones y mejorando nuestros servicios para mantenernos a la vanguardia en la región.
          </p>
        </div>
        <h3 className="text-2xl font-semibold text-gray-800 mb-4 mt-8">Nuestra Misión</h3>
        <p className="mb-4">
          En ALFA LATAM, somos un equipo de expertos apasionados por el mercado financiero latinoamericano. Nuestra misión es empoderar a nuestros clientes con las herramientas, el conocimiento y la asesoría necesaria para tomar decisiones de inversión inteligentes y rentables.
        </p>
        <p>
          Creemos en la transparencia, la educación y el compromiso a largo plazo con el éxito de nuestros clientes. Únete a la comunidad de ALFA LATAM y transforma tu futuro financiero.
        </p>
      </div>
    </div>
  );
};

export default AboutPage;

// DONE
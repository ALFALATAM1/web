import React from 'react';

const HomePage = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] bg-gray-100 p-8">
      <h2 className="text-5xl font-extrabold text-gray-800 mb-6 text-center">
        Tu Socio Estratégico en el Mercado
      </h2>
      <p className="text-xl text-gray-600 mb-8 text-center max-w-2xl">
        Ofrecemos soluciones innovadoras y personalizadas para maximizar tus inversiones en el mercado latinoamericano.
      </p>
      <button className="bg-red-700 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-red-600 transition-all shadow-lg">
        Conoce Más
      </button>
    </div>
  );
};

export default HomePage;
import React from 'react';

const LayoutHeader = ({ setCurrentPage }) => {
  return (
    <header className="bg-white text-red-700 p-4 shadow-md flex justify-between items-center">
      <h1 className="text-2xl font-bold">ALFA LATAM</h1>
      <nav>
        <ul className="flex space-x-4">
          <li>
            <button onClick={() => setCurrentPage('home')} className="hover:text-red-500 transition-colors">Inicio</button>
          </li>
          <li>
            <button onClick={() => setCurrentPage('services')} className="hover:text-red-500 transition-colors">Servicios</button>
          </li>
          <li>
            <button onClick={() => setCurrentPage('about')} className="hover:text-red-500 transition-colors">Nosotros</button>
          </li>
          <li>
            <button onClick={() => setCurrentPage('contact')} className="hover:text-red-500 transition-colors">Contacto</button>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default LayoutHeader;
import React from 'react';

const ServicesPage = () => {
  const services = [
    { title: 'Asesoría Personalizada', description: 'Guía experta para tus decisiones de inversión.' },
    { title: 'Plataformas Avanzadas', description: 'Acceso a tecnología de punta para trading.' },
    { title: 'Capacitación Continua', description: 'Programas educativos para todos los niveles.' },
    { title: 'Análisis de Mercado', description: 'Reportes detallados y proyecciones económicas.' },
  ];

  return (
    <div className="min-h-[calc(100vh-64px)] bg-white p-8">
      <h2 className="text-4xl font-bold text-center text-red-700 mb-10">Nuestros Servicios</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
        {services.map((service, index) => (
          <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 border border-gray-200">
            <h3 className="text-2xl font-semibold text-gray-800 mb-3">{service.title}</h3>
            <p className="text-gray-600">{service.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServicesPage;
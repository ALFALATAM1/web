import React from 'react';

const TestimonialsSection = () => {
  const testimonials = [
    {
      quote: "Gracias a Alfa Latam Trading, mis inversiones han crecido exponencialmente. Su asesoría es invaluable.",
      author: "Carlos M., Inversionista",
    },
    {
      quote: "La plataforma es muy intuitiva y el soporte es excelente. ¡Totalmente recomendados!",
      author: "Ana G., Trader Profesional",
    },
    {
      quote: "Empecé sin saber nada y con su capacitación, ahora me siento seguro operando en el mercado.",
      author: "Luis P., Nuevo Inversor",
    },
  ];

  return (
    <section className="bg-gray-100 py-12">
      <h2 className="text-4xl font-bold text-center text-red-700 mb-10">Lo que dicen nuestros clientes</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto px-4">
        {testimonials.map((testimonial, index) => (
          <div key={index} className="bg-white p-6 rounded-lg shadow-lg border border-gray-200 flex flex-col justify-between">
            <p className="text-gray-700 text-lg italic mb-6">"{testimonial.quote}"</p>
            <p className="text-red-700 font-semibold text-right">- {testimonial.author}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default TestimonialsSection;